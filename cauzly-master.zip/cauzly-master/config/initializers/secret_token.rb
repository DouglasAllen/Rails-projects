# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Cauzly::Application.config.secret_token = '80dfe6a6aadf1446aa84ab1784ca6fd45d2830357393ade6f96eaf178fd693e6960c59180446e288197a2280890a22b8d91c825b6e83e91f544d2a15bbdbef80'
