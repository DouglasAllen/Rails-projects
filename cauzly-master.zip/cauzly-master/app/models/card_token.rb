class CardToken < ActiveRecord::Base
  belongs_to :user
end
