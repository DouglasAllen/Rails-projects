class CampaignVideo < Video
  belongs_to :campaign
end