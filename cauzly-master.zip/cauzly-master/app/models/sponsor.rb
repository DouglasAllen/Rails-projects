class Sponsor < ActiveRecord::Base
end
