class UserVideo < Video
  

 #attr_accessible :video_url,:videoable_id,:videoable_type,:video_title


end