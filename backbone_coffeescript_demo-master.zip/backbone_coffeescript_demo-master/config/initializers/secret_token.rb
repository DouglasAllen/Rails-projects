# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
BackboneTodo::Application.config.secret_token = '9422d2583d9d5d904ef9dac500548208637b43057a9bffefdb33f79c34b395958a2730041646bc4dfd63da0d8acee64ef11a8ac13dd5dfd31642b1d7ffc65c3e'
