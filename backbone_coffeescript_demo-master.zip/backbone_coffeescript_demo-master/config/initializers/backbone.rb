# for Backbone.js
ActiveRecord::Base.include_root_in_json = false
