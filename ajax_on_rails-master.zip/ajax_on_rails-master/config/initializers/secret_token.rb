# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
AjaxOnRails::Application.config.secret_token = 'bc09d45290118823d19f85065364caf240fe28f2ebcbc1a102b07b804466b02d35688b076f923d1d3b3b0c49fcba7169b69b64e3ab4c3e044caa79332af56178'
