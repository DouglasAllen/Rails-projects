class ProjectsController < InheritedResources::Base
  respond_to :html, :json
end
