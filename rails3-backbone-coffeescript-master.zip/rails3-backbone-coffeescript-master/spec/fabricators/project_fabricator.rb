Fabricator(:project) do
  name ""
  description ""
end
