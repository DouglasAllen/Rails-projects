Fabricator(:user) do
end
