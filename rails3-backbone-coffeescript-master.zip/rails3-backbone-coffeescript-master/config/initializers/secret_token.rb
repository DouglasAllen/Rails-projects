# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rails3BackboneCoffeescript::Application.config.secret_token = 'd25312c7e58bf99347cf84aa7ef590a9fca85fd697995d59017d0cdec02eb2ec108f71540daeb71dd45e2d6a14acbbd7d3785cdf475d7960c82a9a6850144efe'
