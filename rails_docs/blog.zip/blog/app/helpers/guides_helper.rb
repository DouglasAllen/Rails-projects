module GuidesHelper
end
