class GuidesController < ApplicationController
  def index
  end
end
