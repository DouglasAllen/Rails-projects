# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
AppWMongo::Application.config.secret_token = '23251f6a4452a1bcde03d504eae57eb1d88f687ff114f123ef9aa00095011d4467234c696af142ac89781ac7687dbe8eb746ef1b1c6a011fc84745e11287c195'
