railsinstaller_demo
===================