# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
RailsinstallerDemo::Application.config.secret_token = '261041f012f978746545910d37486ec913e9b0c7c1b3cd31c3e63f0e84ce95867d41a7fc0e0d4a9f12c851625fa390807e682e165d2c88be29f2697085376182'
